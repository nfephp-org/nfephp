-- phpMyAdmin SQL Dump
-- version 3.1.2deb1
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tempo de Geração: Jun 18, 2009 as 05:46 PM
-- Versão do Servidor: 5.0.75
-- Versão do PHP: 5.2.6-3ubuntu4.1

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Banco de Dados: `nfe`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `nfes`
--

CREATE TABLE IF NOT EXISTS `nfes` (
  `id` int(11) NOT NULL COMMENT 'Id da Tabela',
  `nfe_id` varchar(44) NOT NULL COMMENT 'Identificação da NFe',
  `nfe_numnf` int(11) NOT NULL COMMENT 'Numero da NF',
  `nfe_ent_format` varchar(3) NOT NULL COMMENT 'Formato na entrada TXT ou XML',
  `nfe_ent_time` datetime NOT NULL COMMENT 'Data e Hora da Leitura',
  `nfe_sign_time` datetime NOT NULL COMMENT 'Data e Hora da Assinatura Digital',
  `nfe_intval_status` tinyint(4) NOT NULL COMMENT 'Statusda Validação Interna 0-Falha 1-OK',
  `nfe_lote` int(11) NOT NULL COMMENT 'Numero do lote de envio',
  `nfe_lote_time` datetime NOT NULL COMMENT 'Data e hora da ciração do lote de envio',
  `nfe_SEFAZ_envtime` datetime NOT NULL COMMENT 'DAta e hora do envio ao SEFAZ',
  `nfe_sefaz_retstatus` tinyint(4) NOT NULL COMMENT 'Status da NFe no SEFAZ',
  `nfe_sefaz_rettime` datetime NOT NULL COMMENT 'Data e hora do retorno do SEFAZ',
  `nfe_sefaz_protocol` varchar(44) NOT NULL COMMENT 'Numero do protocolo de aceitação do SEFAZ',
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Cadastro das NFe tratadas pelo sistema';

--
-- Extraindo dados da tabela `nfes`
--

